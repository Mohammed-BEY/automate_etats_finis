/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

/**
 *
 * @author mohammed_bey
 */
public class Alphabet extends ClasseMereGraphique {

    public Alphabet() {
        label1.setText("ALphabet = { ");
        label2.setText(" }");
        tField1.setPromptText("x1,x2,...,xn");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1, label2);
    }

    @Override
    public String toString() {
        return "Alphabet X = {" + tField1.getText() + "}\n";
    }
}
