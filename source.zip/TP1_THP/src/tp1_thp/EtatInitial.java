/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

import static tp1_thp.FXMLDocumentController.contPrinc;

/**
 *
 * @author mohammed_bey
 */
public class EtatInitial extends ClasseMereGraphique {

    public EtatInitial() {
        label1.setText("Etat initial :  ");
        tField1.setPromptText("S0");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1);
    }

    @Override
    public String toString() {
        return "État initial = " + tField1.getText() + "\n";
    }

    //contrôler l'état initial
    public String traiter() {
        String result = "", tmp = ((EtatInitial) contPrinc.getChildren().get(2)).tField1.getText().replaceAll(" ", "");
        Controle ctrl = new Controle();
        ctrl.remplirListE();
        if (!tmp.equals("")) {
            String[] tab = tmp.split(",");
            if (tab.length > 1) {
                result += "Attention! il y a plus d'un état initial.\n";
            } else {
                try {
                    Double.parseDouble(tField1.getText());
                    result += "Attetntion! l'état initial est constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!ctrl.getListEtats().contains(tField1.getText())) {
                        result += "Attention! l'état initial '" + tField1.getText().replaceAll(" ", "") + "' n'a pas été défini.\n";
                    }
                }
            }
        }

        return ctrl.getListEtats().get(ctrl.getListEtats().size() - 1) + result;
    }
}
