/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

/**
 *
 * @author mohammed_bey
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

//La classe Boite de dialogue de la confirmation de la suppression d'un bloc d'instructions et les modules internes
public class BoiteDeDialogue extends Group {

    final Stage stage;
    Label messError;

    public BoiteDeDialogue(String str) {
        messError = new Label(str);
        ImageView image = new ImageView(new Image(TP1_THP.class.getResourceAsStream("images/info.png")));
        image.setFitHeight(60);
        image.setPreserveRatio(true);
        //ajouter les elements au groupe
        getChildren().addAll(image, messError);
        messError.setLayoutX(70);
        messError.setLayoutY(50);
        image.setLayoutY(30);
        stage = new Stage();
        stage.setResizable(false);
        stage.setScene(new Scene(this, 330, 100));
        stage.show();
        stage.setTitle("   erreur détectée  ");
    }
}
