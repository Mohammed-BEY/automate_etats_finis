/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

import java.util.ArrayList;
import static tp1_thp.FXMLDocumentController.contPrinc;

/**
 *
 * @author mohammed_bey
 */
//Classe non graphique où se font les traitements
public class Automate {

    private final Controle ctrl = new Controle();
    String chemin = "";
    private ArrayList<String> result = new ArrayList<String>();//contient les états accessibles et coaccessibles

    public Automate() {
        contPrinc.getChildren().add(new Alphabet());
        contPrinc.getChildren().add(new EnsEtats());
        contPrinc.getChildren().add(new EtatInitial());
        contPrinc.getChildren().add(new EnsEtatsFinaux());
        contPrinc.getChildren().add(new EnsInstructions());
        //ajuster lesp oditions x et y
        contPrinc.getChildren().get(1).setLayoutY(23 * 1);
        contPrinc.getChildren().get(2).setLayoutY(23 * 2);
        contPrinc.getChildren().get(3).setLayoutY(23 * 3);
        contPrinc.getChildren().get(4).setLayoutY(23 * 4);
    }

    public String afficherAutomate() {
        String result = "";
        int j = contPrinc.getChildren().size();
        for (int i = 0; i < j; i++) {
            result += contPrinc.getChildren().get(i).toString();
        }
        if (result.endsWith(",")) {
            result = result.substring(0, result.length() - 1);//enlever la dernière virgule   
        }
        result += "}";
        return result;
    }

    public boolean reconnaitreMot(String mot) {
        chemin = "";//initialiser le chemin
        boolean reconnu = true;
        //tester si le mot ne contient que les symbols définis dans l'alphabet
        ctrl.remplirListS();
        ctrl.remplirListIns();
        ctrl.remplirListEF();
        int i = 0;
        while (reconnu && i < mot.length()) {
            if (!ctrl.getListSymbols().contains(String.valueOf(mot.charAt(i)))) {//symbol non reconnu
                reconnu = false;
            }
            i++;
        }
        //tous les caracteres constitant le mot appartiennent à l'alphabet
        //vérifier avec les états de l'automate        
        if (reconnu) {
            String Si = ((EtatInitial) contPrinc.getChildren().get(2)).tField1.getText(),//initialiser Si à l'état initial
                    Sj = "";
            char xi;
            i = 0;
            boolean stop = false;
            while (!stop && i < mot.length()) {
                xi = mot.charAt(i);
                Sj = passInst(Si, xi);
                if (Sj.equals("0")) {//chemin bloqué
                    //Le mot n'est pas reconnu
                    stop = true;
                } else {//aller au prochain symbol
                    i++;
                    chemin += Si + " " + xi + " ";
                    Si = Sj;
                    chemin += Sj + " ,  ";
                }
            }
            if (stop) {//blockage au milieu du mot
                reconnu = false;
            } else if (Sj.equals("0")) {//blockage à la fin
                reconnu = false;
            } else if (ctrl.getListEtatsF().contains(Sj)) {//atteinte de l'etat final (chamin reussi)
                reconnu = true;
            } else {//atteinte du dernier caractere mais le dernier etat n'appartient pas à l'etat final
                reconnu = false;
            }
        }
        return reconnu;
    }

    //détecter quelques éventuelles erreurs
    public String traiter() {
        String result = "", tmp = "";
        int j = contPrinc.getChildren().size();
        ctrl.remplirListS();
        ctrl.remplirListIns();
        tmp = ctrl.getListSymbols().get(ctrl.getListSymbols().size() - 1);//erreur des symbols
        if (!tmp.equals("")) {
            result += tmp;
        }
        result += ((EtatInitial) contPrinc.getChildren().get(2)).traiter();
        result += ((EnsEtatsFinaux) contPrinc.getChildren().get(3)).traiter();
        //les instructions
        result += ctrl.getListIns().get(ctrl.getListIns().size() - 1);//resuperer les erreurs détectées lors du remplissage de la liste des instructions
        for (int k = 5; k < j; k++) {
            result += ((InstructionDecl) contPrinc.getChildren().get(k)).traiter(ctrl.getListSymbols(), ctrl.getListEtats());
        }
        return result;
    }

    //compléter l'automate
    public void completerAuto() {
        ctrl.remplirListS();
        ctrl.remplirListE();
        ctrl.remplirListEF();
        ctrl.remplirListIns();
        String tmp = "", SP = "";
        int sizeCon = contPrinc.getChildren().size();
        int sizeS = ctrl.getListSymbols().size() - 1,
                sizeE = ctrl.getListEtats().size() - 1;
        for (int i = 0; i < sizeE; i++) {//parcourir tous les états
            for (int j = 0; j < sizeS; j++) {//parcourir tous les symboles
                if (passInst(ctrl.getListEtats().get(i), ctrl.getListSymbols().get(j).charAt(0)).equals("0")) {//il n'y a pas un passage de Si à travers xi
                    //créer un état puit et ajouter l'instruction à la liste des instructions
                    SP = "SP";
                    tmp = ctrl.getListEtats().get(i) + " " + ctrl.getListSymbols().get(j) + " " + "SP";
                    ctrl.getListIns().add(ctrl.getListIns().size() - 1, tmp);
                    ((Instruction) contPrinc.getChildren().get(sizeCon - 1)).ajouterEl(new InstructionDecl(tmp));
                    sizeCon++;
                }
            }
        }
        if (!SP.equals("") && !((EnsEtats) contPrinc.getChildren().get(1)).tField1.getText().contains(SP)) {
            ((EnsEtats) contPrinc.getChildren().get(1)).tField1.appendText("," + SP);//ajouter l'état puit à l'ensemble des états dans la construction de l'auto
            ctrl.getListEtats().add(ctrl.getListEtats().size() - 1, SP);
        }
    }

    private void etatAccEtCoacc() {
        ArrayList<String> listAccess = etatsAccessibles(),
                listCoaccess = etatsCoaccessibles();
        result.clear();
        result.addAll(listAccess);
        for (String string : listCoaccess) {
            if (!result.contains(string)) {
                result.add(string);
            }
        }
        listAccess.stream().filter((listAcces) -> (listCoaccess.contains(listAcces))).forEach((listAcces) -> {
            result.remove(listAcces);
        });
        for (String listCoAcc : listCoaccess) {
            if (listAccess.contains(listCoAcc)) {
                result.remove(listCoAcc);
            }
        }
    }

    //réduire un automate
    public void reduireAuto() {
        ctrl.remplirListIns();
        ctrl.remplirListEF();
        ctrl.remplirListE();
        etatAccEtCoacc();
        result.stream().forEach((String string) -> {//état non accessible ou non coaccessible
            int j = ctrl.getListIns().size() - 1;
            int tai = 0;
            String tmp = "";
            if (ctrl.getListEtatsF().contains(string)) {//enlever de la liste des états finaux
                ctrl.getListEtatsF().remove(string);
                tai = ctrl.getListEtatsF().size();
                for (int i = 0; i < tai - 1; i++) {
                    tmp += ctrl.getListEtatsF().get(i) + ",";
                }
                int end = tmp.lastIndexOf(",");
                ((EnsEtatsFinaux) contPrinc.getChildren().get(3)).tField1.setText(tmp.substring(0, end));
            }
            tmp = "";
            if (ctrl.getListEtats().contains(string)) {//enlever de la liste des états
                ctrl.getListEtats().remove(string);
                tai = ctrl.getListEtats().size();
                for (int i = 0; i < tai - 1; i++) {
                    tmp += ctrl.getListEtats().get(i) + ",";
                }
                int end = tmp.lastIndexOf(",");
                ((EnsEtats) contPrinc.getChildren().get(1)).tField1.setText(tmp.substring(0, end));
            }
            int cptSup = 0;
            j = ctrl.getListIns().size() - 1;
            for (int i = 0; i < j; i++) {//les instructions
                if (ctrl.getListIns().get(i).contains(string)) {
                    ((Instruction) contPrinc.getChildren().get(4)).supprimerEl(5 + i - cptSup);
                    cptSup++;
                }
            }
        });
    }

    //recupérer la liste des états accessibles
    private ArrayList etatsAccessibles() {
        ArrayList<String> listAccess = new ArrayList();
        ctrl.remplirListS();
        ctrl.remplirListIns();
        String Si = ((EtatInitial) contPrinc.getChildren().get(2)).tField1.getText(),
                Sj = "";
        char xi = 0;
        listAccess.add(Si);//ajouter l'état initial à la liste
        int j = ctrl.getListSymbols().size() - 1;
        for (int i = 0; i < listAccess.size(); i++) {//les états accessibles            
            Si = listAccess.get(i);
            for (int k = 0; k < j; k++) {//les symboles                 
                xi = ctrl.getListSymbols().get(k).charAt(0);
                Sj = passInst(Si, xi);
                if (!Sj.equals("0") && !listAccess.contains(Sj)) {
                    listAccess.add(Sj);
                }
            }
        }
        return listAccess;
    }

    //recupérer la liste des états coaccessibles
    private ArrayList etatsCoaccessibles() {
        ArrayList<String> listCoaccess = new ArrayList();
        ctrl.remplirListS();
        ctrl.remplirListE();
        ctrl.remplirListEF();
        ctrl.remplirListIns();

        String Si = "";
        char xi;
        int f = ctrl.getListEtatsF().size() - 1,
                s = ctrl.getListSymbols().size() - 1;
        for (int i = 0; i < f; i++) {//parcourir la liste de états finaux
            listCoaccess.add(ctrl.getListEtatsF().get(i).replaceAll(" ", ""));//ajouter l'état final comme état coaccessible
        }
        for (int i = 0; i < listCoaccess.size(); i++) {//parcourir la liste de états finaux
            for (int j = 0; j < s; j++) {//la liste des symboles
                //pour chaque caractére
                xi = ctrl.getListSymbols().get(j).charAt(0);
                Si = passInst(xi, listCoaccess.get(i));
                if (!Si.equals("0")) {//il y a des prédécesseurs
                    String tabInsSi[] = Si.split("#");
                    for (String string : tabInsSi) {//ajouter les prédécesseurs des états qui ménent vers l'état final à la liste
                        if (!listCoaccess.contains(string)) {
                            listCoaccess.add(string.replaceAll(" ", ""));//ajouter l'état comme état coaccessible
                        }
                    }
                }
            }
        }
        return listCoaccess;
    }

    //resuperer l'automate tel qu'il est
    public String graphStatus() {
        String result = "digraph" + "\n{\n" + "rankdir=LR;\n" + "node [shape = circle, width = 0.5];\n";
        ctrl.remplirListE();
        ctrl.remplirListEF();
        ctrl.remplirListIns();
        int k = 0;
        for (int i = 0; i < ctrl.getListIns().size() - 1; i++) {
            String[] tab = ctrl.getListIns().get(i).split(" ");
            k = 0;
            if (k < tab.length) {
                result += tab[k] + "->";
                k += 2;
            }
            if (k < tab.length) {
                result += tab[k];
                k--;
            }
            if (k < tab.length) {
                result += "[label=\"" + tab[k] + "\",weight=\"" + tab[k] + "\"]\n";
            }
        }
        //colorer les états finaux
        for (int i = 0; i < ctrl.getListEtatsF().size() - 1; i++) {
            for (int l = 0; l < ctrl.getListIns().size() - 1; l++) {
                if (ctrl.getListIns().get(l).contains(ctrl.getListEtatsF().get(i))) {
                    result += ctrl.getListEtatsF().get(i) + " [style = filled, fillcolor=palegreen ];\n";
                }
            }
        }

        for (int l = 0; l < ctrl.getListIns().size() - 1; l++) {
            //colorer l'état initial
            if (ctrl.getListIns().get(l).contains(((EtatInitial) contPrinc.getChildren().get(2)).tField1.getText().replaceAll(" ", ""))) {
                result += ((EtatInitial) contPrinc.getChildren().get(2)).tField1.getText().replaceAll(" ", "") + " [style = filled, fillcolor=yellow ];\n";
            }
            //colorer l'état puit
            if (ctrl.getListIns().get(l).contains("SP")) {
                result += "SP" + " [style = filled, fillcolor=orange ];\n";
            }
        }
        result += "}";
        return result;
    }

//permet de savoir si on peut passer à travers xi de l'état Si à un état Sj
    private String passInst(String Si, char xi) {
        String result = "";
        int i = 0, j = ctrl.getListIns().size();
        boolean fin = false;
        while (!fin && i < j - 1) {
            String tab[] = ctrl.getListIns().get(i).split(" ");
            if (tab.length == 3) {//instrution complete
                if (tab[0].equals(Si) && tab[1].equals(String.valueOf(xi))) {//il existe une instruction qui permet de passer de Si à Sj à travers xi
                    result = tab[2].replaceAll(" ", "");
                    fin = true;
                }
            }
            i++;
        }
        if (!fin) {
            result = "0";
        }
        return result;
    }

    //permet de savoir s'il y a des états Si tel qu'on peut passer à travers xi de l'état Si à un état Sj
    private String passInst(char xi, String Sj) {
        String result = "";
        int i = 0, j = ctrl.getListIns().size();
        while (i < j - 1) {
            String tab[] = ctrl.getListIns().get(i).split(" ");
            if (tab.length == 3) {//instrution complete
                if (tab[2].equals(Sj) && tab[1].equals(String.valueOf(xi))) {//il existe une instruction qui permet de passer de Si à Sj à travers xi
                    result += tab[0].replaceAll(" ", "") + "#";
                }
            }
            i++;
        }
        if (result.equals("")) {
            result = "0";
        }
        return result;
    }

    //verifier si l'automate est complet ou pas
    public boolean estVide() {
        boolean result = false;
        for (int i = 0; i < 4; i++) {
            if (((Alphabet) contPrinc.getChildren().get(0)).tField1.getText().replaceAll(" ", "").equals("")) {
                result = true;
            } else if (((EnsEtats) contPrinc.getChildren().get(1)).tField1.getText().replaceAll(" ", "").equals("")) {
                result = true;
            } else if (((EtatInitial) contPrinc.getChildren().get(2)).tField1.getText().replaceAll(" ", "").equals("")) {
                result = true;
            } else if (((EnsEtatsFinaux) contPrinc.getChildren().get(3)).tField1.getText().replaceAll(" ", "").equals("")) {
                result = true;
            }
        }
        return result;
    }
}
