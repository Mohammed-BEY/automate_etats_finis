/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author mohammed_bey
 */
public class FXMLDocumentController implements Initializable {

    //le conteneur principal de l'Editeur
    @FXML
    ScrollPane sp;
    @FXML
    TextField tfMot;//ecrire le mot à reconnaitre
    @FXML
    TextArea txChemin;//afficher tous les états pour obtenir le mot demandé par l'utilisateur
    @FXML
    TextArea txCtrlError;//afficher les erreurs
    @FXML
    TextArea txDisplay;//afficher l'automate
    public static AnchorPane contPrinc = new AnchorPane();//conteneur des objets
    private Automate auto;
    private final AnchorPane anch = new AnchorPane();//conteneur de l'image de l'automate    
    private BoiteDeDialogue boxError = null;

    @FXML
    void afficher() throws IOException, InterruptedException {
        traiter();
        if (txCtrlError.getText().equals("il n'y a aucune erreur détectée.")) {
            txDisplay.setText(auto.afficherAutomate());
            File defaultDirectory = new File(".\\graphes");//initialiser le répertoire par défaut
            if (!defaultDirectory.exists()) {
                defaultDirectory.mkdir();
            }
            //****Sauvegarder l'état du graphe dans un fichier
            String NomFichier = ".\\graphes\\graph.txt";
            try {
                try (PrintWriter out = new PrintWriter(new FileWriter(NomFichier))) {
                    out.println(auto.graphStatus());
                }
            } catch (IOException e) {
            }
            try {
                Runtime.getRuntime().exec(".\\graphviz\\dot.exe -Tpng "
                        + defaultDirectory + "\\graph.txt -o "
                        + defaultDirectory + "\\auto.png").waitFor();
            } catch (IOException ex) {
            }
            String[] commands = {
                //                "cmd.exe", "/c", "start", "\"DummyTitle\"", "\"" + ".\\src\\tp1_thp\\images\\auto.png" + "\""
                "cmd.exe", "/c", "start", "\"DummyTitle\"", "\"" + ".\\graphes\\auto.png" + "\""
            };
            Process p = Runtime.getRuntime().exec(commands);
            try {
                p.waitFor();
            } catch (InterruptedException ex) {
            }
        } else {
            //afficher un message d'erreur
            boxError = new BoiteDeDialogue("       Veuillez corriger les erreurs.");
        }
    }

    @FXML
    void completerAuto() {
        traiter();
        if (txCtrlError.getText().equals("il n'y a aucune erreur détectée.")) {
            auto.completerAuto();
        } else {
            //afficher un message d'erreur
            boxError = new BoiteDeDialogue("       Veuillez corriger les erreurs.");
        }
    }

    @FXML
    void reduireAuto() {
        traiter();
        if (txCtrlError.getText().equals("il n'y a aucune erreur détectée.")) {
            auto.reduireAuto();
        } else {
            //afficher un message d'erreur
            boxError = new BoiteDeDialogue("       Veuillez corriger les erreurs.");
        }
    }

    @FXML
    void recoonaitreUnMot() {
        traiter();
        if (txCtrlError.getText().equals("il n'y a aucune erreur détectée.")) {
            if (tfMot.getText().equals("")) {
                txChemin.setText("Veuillez donner un mot.");
            } else {
                if (auto.traiter().equals("")) {//il n'y a aucune erreur détectée
                    boolean reconnu = auto.reconnaitreMot(tfMot.getText());
                    if (reconnu) {
                        txChemin.setText(auto.chemin);
                    } else {
                        txChemin.setText("Le mot introduit n'est reconnu par cet automate.");
                    }
                } else {
                    txChemin.setText("Veuillez vérifier l'automate, il comporte des erreurs.");
                }
            }
        } else {
            //afficher un message d'erreur
            boxError = new BoiteDeDialogue("       Veuillez corriger les erreurs.");
        }
    }

    @FXML
    void traiter() {
        if (!auto.estVide()) {
            String tmp = auto.traiter();
            if (tmp.equals("")) {
                txCtrlError.setText("il n'y a aucune erreur détectée.");
            } else {
                txCtrlError.setText(tmp);
            }
        } else {
            //afficher un message d'erreur
            boxError = new BoiteDeDialogue("Veuillez remplir tous les champs de l'automate.");
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        anch.getStyleClass().add("anchorpane");
        auto = new Automate();
        sp.setContent(contPrinc);
        contPrinc.getStyleClass().add("anchorpane");
        tfMot.setOnAction((ActionEvent e) -> {
            recoonaitreUnMot();
        });
    }
}
