/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

/**
 *
 * @author mohammed_bey
 */
public class EnsEtatsFinaux extends ClasseMereGraphique {

    public EnsEtatsFinaux() {
        label1.setText("Ensemble des états finaux = { ");
        label2.setText(" }");
        tField1.setPromptText("S0,S1,...,Sn");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        getChildren().addAll(label1, tField1, label2);
    }

    @Override
    public String toString() {
        return "Ensemble des états finaux = {" + tField1.getText() + "}\n";
    }

    //contrôler les états finaux
    public String traiter() {
        String result = "";
        Controle ctrl = new Controle();
        ctrl.remplirListEF();
        ctrl.remplirListE();
        String tmp = tField1.getText().replaceAll(" ", "");
        String[] tab = tmp.split(",");
        for (String string : tab) {
            if (!ctrl.getListEtats().contains(string)) {
                result += "Attention! l'état final '" + string + "' n'a pas été défini.\n";
            }
        }
        return result + ctrl.getListEtatsF().get(ctrl.getListEtatsF().size() - 1);
    }
}
