/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

import java.util.HashMap;
import java.util.Map;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;

/**
 *
 * @author mohammed_bey
 */
public class ClasseMereGraphique extends HBox {

    protected Label label1, label2, label3;
    protected TextField tField1, tField2, tField3;
    private final Map<Character, Double> tab = new HashMap<>();

    public ClasseMereGraphique() {
        remplirMapLengthCahr();//remplir le tableau associatif
        label1 = new Label();
        label2 = new Label();
        label3 = new Label();
        tField1 = new TextField();
        tField2 = new TextField();
        tField3 = new TextField();
        //mise en forme
        tField1.getStyleClass().add("textfield");
        tField2.getStyleClass().add("textfield2");
        tField3.getStyleClass().add("textfield");
        tField1.setPrefHeight(21);
        tField1.setAlignment(Pos.TOP_LEFT);
        tField2.setPrefHeight(21);
        tField2.setAlignment(Pos.TOP_LEFT);
        tField3.setPrefHeight(21);
        tField3.setAlignment(Pos.TOP_LEFT);
        //mettre les champs de saisie en taille dynamique
        tField1.textProperty().addListener((ObservableValue<? extends String> ov, String t, String t1) -> {
            if (tField1.getText().length() == 0) {
                tField1.setPrefWidth(longChar(tField1.getPromptText()));
            } else {
                tField1.setPrefWidth(longChar(tField1.getText()));
            }
        });        
        tField3.textProperty().addListener((ObservableValue<? extends String> ov, String t, String t1) -> {
            if (tField3.getText().length() == 0) {
                tField3.setPrefWidth(longChar(tField3.getPromptText()));
            } else {
                tField3.setPrefWidth(longChar(tField3.getText()));
            }
        });
        //centrer les elements de HBox
        setAlignment(Pos.TOP_LEFT);
    }

    //retourne la longueur du caractére
    protected double longChar(String str) {
        double result = 0;
        for (int i = 0; i < str.length(); i++) {
            if (tab.containsKey(str.charAt(i))) {
                result += tab.get(str.charAt(i));
            } else {
                result += 7.0;
            }
        }
        return result;
    }

    private void remplirMapLengthCahr() {
        tab.put('a', 6.3);
        tab.put('b', 7.0);
        tab.put('c', 6.3);
        tab.put('d', 7.0);
        tab.put('e', 6.3);
        tab.put('f', 4.7);
        tab.put('g', 7.0);
        tab.put('h', 7.0);
        tab.put('i', 4.0);
        tab.put('j', 4.0);
        tab.put('k', 7.0);
        tab.put('l', 4.0);
        tab.put('m', 11.3);
        tab.put('n', 7.0);
        tab.put('o', 7.0);
        tab.put('p', 7.0);
        tab.put('q', 7.0);
        tab.put('r', 4.7);
        tab.put('s', 5.5);
        tab.put('t', 4.0);
        tab.put('u', 7.0);
        tab.put('v', 7.0);
        tab.put('w', 10.4);
        tab.put('x', 7.0);
        tab.put('y', 7.0);
        tab.put('z', 6.3);
        //pour les lettres majuscules
        tab.put('A', 10.3);
        tab.put('B', 9.7);
        tab.put('C', 9.7);
        tab.put('D', 10.5);
        tab.put('E', 8.9);
        tab.put('F', 8.0);
        tab.put('G', 10.7);
        tab.put('H', 10.2);
        tab.put('I', 4.8);
        tab.put('J', 5.5);
        tab.put('K', 10.7);
        tab.put('L', 9.0);
        tab.put('M', 12.3);
        tab.put('N', 10.5);
        tab.put('O', 10.7);
        tab.put('P', 7.8);
        tab.put('Q', 10.5);
        tab.put('R', 9.5);
        tab.put('S', 7.8);
        tab.put('T', 8.8);
        tab.put('U', 10.5);
        tab.put('V', 10.5);
        tab.put('W', 14.0);
        tab.put('X', 10.7);
        tab.put('Y', 10.3);
        tab.put('Z', 8.8);
        //pour les caractéres speciaux
        tab.put('à', 6.3);
        tab.put('é', 6.3);
        tab.put('è', 6.3);
        tab.put('ù', 7.0);
        tab.put('ô', 7.0);
        tab.put('â', 6.3);
        tab.put('î', 4.0);
        tab.put('û', 7.0);
        tab.put('ê', 6.3);
        tab.put('ĵ', 4.0);
        tab.put('ŷ', 7.0);
        tab.put('^', 7.0);
        tab.put('È', 8.9);
        tab.put('À', 10.3);
        tab.put('É', 8.9);
        tab.put('[', 4.85);
        tab.put(']', 4.85);
        tab.put('{', 6.7);
        tab.put('}', 6.7);
        tab.put(' ', 3.5);
        tab.put('.', 3.5);
        tab.put(',', 3.5);
        tab.put(';', 4.0);
        tab.put(':', 4.0);
        tab.put('=', 8.0);
        tab.put('\'', 2.7);
        tab.put('"', 6.0);
        tab.put('\\', 4.3);
        tab.put('*', 7.0);
        tab.put('+', 8.0);
        tab.put('-', 5.0);
        tab.put('!', 4.8);
        tab.put('@', 13.8);
        tab.put('#', 7.2);
        tab.put('$', 7.4);
        tab.put('%', 12.4);
        tab.put('?', 6.5);
        tab.put('&', 11.5);
        tab.put(')', 4.8);
        tab.put('(', 4.8);
        tab.put('_', 7.0);
        tab.put('|', 3.0);
        tab.put('<', 8.0);
        tab.put('>', 8.0);
        //les chiffres
        tab.put('0', 7.0);
        tab.put('1', 7.0);
        tab.put('2', 7.0);
        tab.put('3', 7.0);
        tab.put('4', 7.0);
        tab.put('5', 7.0);
        tab.put('6', 7.0);
        tab.put('7', 7.0);
        tab.put('8', 7.0);
        tab.put('9', 7.0);
    }
}
