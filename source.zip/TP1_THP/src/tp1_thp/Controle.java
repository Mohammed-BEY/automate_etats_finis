/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

import java.util.ArrayList;
import java.util.List;
import static tp1_thp.FXMLDocumentController.contPrinc;

/**
 *
 * @author mohammed_bey
 */
public class Controle {

    static private final List<String> listSymbols = new ArrayList<>(),//static:car on les modifie lors de complétition de l'auto
            listEtats = new ArrayList<>(),
            listEtatsF = new ArrayList<>(),
            listIns = new ArrayList<>();//liste des instructions

    public List<String> getListIns() {
        return listIns;
    }

    public List<String> getListSymbols() {
        return listSymbols;
    }

    public List<String> getListEtats() {
        return listEtats;
    }

    public List<String> getListEtatsF() {
        return listEtatsF;
    }

    public Controle() {

    }

    //remplir la liste des lettres (symboles)
    public void remplirListS() {
        listSymbols.clear();
        String messError = "";
        if (!((Alphabet) contPrinc.getChildren().get(0)).tField1.getText().replaceAll(" ", "").equals("")) {
            String[] alphabet = ((Alphabet) contPrinc.getChildren().get(0)).tField1.getText().split(",");
            for (String string : alphabet) {
                if (string.length() > 1) {
                    messError += "Attention! il y a un symbole constitué de 2 symboles.\n";
                }
                if (!listSymbols.contains(string)) {
                    listSymbols.add(string);
                } else {//le symbol existe dans la liste des symboles
                    messError += "Attention! il y a un symbol doublé.\n";
                }
            }
        } else {
            messError += "Attention! l'alphabet est vide.\n";
        }
        listSymbols.add(messError);
    }

    //remplir la liste des états
    public void remplirListE() {
        listEtats.clear();
        String messError = "";
        if (!((EnsEtats) contPrinc.getChildren().get(1)).tField1.getText().replaceAll(" ", "").equals("")) {
            String[] etats = ((EnsEtats) contPrinc.getChildren().get(1)).tField1.getText().split(",");
            for (String string : etats) {
                try {
                    Double.parseDouble(string);
                    messError += "Attention! vous avez écrit un état constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!listEtats.contains(string)) {
                        listEtats.add(string);
                    } else {//le symbol existe dans la liste des symboles
                        messError += "Attention! il y a un état doublé.\n";
                    }
                }
            }
        } else {
            messError += "Attention! l'ensemble des états est vide.\n";
        }
        listEtats.add(messError);
    }

    //remplir la liste des états finaux
    public void remplirListEF() {
        listEtatsF.clear();
        String messError = "";
        if (!((EnsEtatsFinaux) contPrinc.getChildren().get(3)).tField1.getText().replaceAll(" ", "").equals("")) {
            String[] etatsF = ((EnsEtatsFinaux) contPrinc.getChildren().get(3)).tField1.getText().split(",");
            for (String string : etatsF) {
                try {
                    Double.parseDouble(string);
                    messError += "Attention! vous avez écrit un état final constitué uniquement des chiffres.\n";
                } catch (NumberFormatException e) {
                    if (!listEtatsF.contains(string)) {
                        listEtatsF.add(string);
                    } else {//l'état est déjà utilisé
                        messError += "Attention! il y a un état final doublé.\n";
                    }
                }
            }
        } else {
            messError += "Attention! l'ensemble des états finaux est vide.\n";
        }
        listEtatsF.add(messError);
    }

    //remplir la liste des instructions
    public void remplirListIns() {
        listIns.clear();
        int j = contPrinc.getChildren().size();
        String tmp = "", messError = "";
        for (int k = 5; k < j; k++) {
            tmp = contPrinc.getChildren().get(k).toString().replaceAll(",", "");
            if (!listIns.contains(tmp)) {
                listIns.add(tmp);
            } else {
                messError += "Attetion! l'instruction '" + tmp + "' est doublée.\n";
            }
        }
        listIns.add(messError);
    }
}
