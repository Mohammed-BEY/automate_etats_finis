/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.Event;
import static tp1_thp.FXMLDocumentController.contPrinc;

/**
 *
 * @author mohammed_bey
 */
public class Instruction extends ClasseMereGraphique {

    protected final iconeMajInst icMAJ;

    public Instruction() {
        icMAJ = new iconeMajInst();
        tField1.setPromptText("Si");
        tField3.setPromptText("Sj");
        tField2.setPromptText("  xi ");
        tField1.setPrefWidth(longChar(tField1.getPromptText()));
        tField3.setPrefWidth(longChar(tField3.getPromptText()));
        tField2.setPrefWidth(30);
        tField2.textProperty().addListener((ObservableValue<? extends String> ov, String t, String t1) -> {
            String str = tField2.getText().replaceAll(" ", "");
            if (str.length() == 1) {
                tField2.setText("   " + str);
            } else if (str.length() == 0) {
                tField2.setText("");
                tField2.setPrefWidth(30);
            } else {
                tField2.deleteNextChar();
            }
        });
        tField3.setOnAction((ActionEvent e) -> {
            ajouterEl(new InstructionDecl());
        });
        //Gérer les evenements sur les menus de MiseÀjour:
        icMAJ.setVisible(false);
        //le menu de MiseAjour apprait quand la souris entre dans la zone de l'objet
        setOnMouseEntered((Event t) -> {
            icMAJ.setVisible(true);
        });
        //le menu de MiseAjour disparait quand la souris sort de la zone de l'objet
        setOnMouseExited((Event t) -> {
            icMAJ.setVisible(false);
        });
        icMAJ.menuAjouter.setOnAction((ActionEvent e) -> {
            ajouterEl(new InstructionDecl());
        });
        icMAJ.menuSupprimer.setOnAction((ActionEvent e) -> {
            int indice = contPrinc.getChildren().indexOf(icMAJ.getParent());
            supprimerEl(indice);
        });
    }

    //La methode d'ajout d'un element
    public void ajouterEl(InstructionDecl el) {
        contPrinc.getChildren().add(el);
        double posY = contPrinc.getChildren().get(contPrinc.getChildren().size() - 2).getLayoutY();
        int index = contPrinc.getChildren().size() - 1;
        switch (index % 3) {
            case 2:
                if (contPrinc.getChildren().size() == 6) {//la premiere instruction
                    el.setLayoutY(23 * 4);
                } else {//nouvelle ligne
                    el.setLayoutY(posY + 23);
                }
                el.setLayoutX(170);
                break;
            case 0:
                el.setLayoutY(posY);
                el.setLayoutX(170 + 100);
                break;
            case 1:
                el.setLayoutY(posY);
                el.setLayoutX(170 + 100 + 100);
                break;
            default:
                throw new AssertionError();
        }
    }

    //La methode de suppression
    public void supprimerEl(int index) {
        contPrinc.getChildren().remove(index);
        int j = contPrinc.getChildren().size();
        double posY;
        for (int i = index; i < j; i++) {            
            switch (i % 3) {
                case 2:
                    contPrinc.getChildren().get(i).setLayoutX(170);
                    break;
                case 0:
                    contPrinc.getChildren().get(i).setLayoutX(170 + 100);
                    break;
                case 1://il étatit dans la ligne précédente
                    posY = contPrinc.getChildren().get(i).getLayoutY();
                    contPrinc.getChildren().get(i).setLayoutY(posY - 23);
                    contPrinc.getChildren().get(i).setLayoutX(170 + 100 + 100);
                    break;
                default:
                    throw new AssertionError();
            }
        }
    }
}
