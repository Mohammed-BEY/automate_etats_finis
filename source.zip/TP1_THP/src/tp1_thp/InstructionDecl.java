/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1_thp;

import java.util.List;

/**
 *
 * @author mohammed_bey
 */
public class InstructionDecl extends Instruction {

    public InstructionDecl() {
        getChildren().addAll(tField1, tField2, tField3, icMAJ);
    }

    public InstructionDecl(String str) {
        String[] tab = str.split(" ");
        int i = 0;
        if (i < tab.length) {
            tField1.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField2.setText(tab[i]);
            i++;
        }
        if (i < tab.length) {
            tField3.setText(tab[i]);
            i++;
        }
        getChildren().addAll(tField1, tField2, tField3, icMAJ);
    }

    @Override
    public String toString() {
        return tField1.getText() + " " + tField2.getText().replaceAll(" ", "") + " " + tField3.getText() + ",";
    }

    //contrôler l'utilisation des symbols et les états
    public String traiter(List listSymb, List listEtat) {
        String result = "";
        if (!listSymb.contains(tField2.getText().replaceAll(" ", ""))) {//on a utilisé un symbole non déclaré
            result += "Attention! le symbol '" + tField2.getText().replaceAll(" ", "") + "' dans une instruction n'a pas été défini.\n";
        }
        try {//pour Si
            Double.parseDouble(tField1.getText());
            result += "Attetntion! l'état '" + tField1.getText().replaceAll(" ", "") + "' dans une instruction est constitué uniquement des chiffres.\n";
        } catch (NumberFormatException e1) {
            if (!listEtat.contains(tField1.getText().replaceAll(" ", ""))) {//on a utilisé un état non déclaré
                result += "Attention! l'état '" + tField1.getText().replaceAll(" ", "") + "' dans une instruction n'a pas été défini.\n";
            }
        }
        try {//pour Sj
            Double.parseDouble(tField3.getText());
            result += "Attetntion! l'état '" + tField3.getText().replaceAll(" ", "") + "' dans une instruction est constitué uniquement des chiffres.\n";
        } catch (NumberFormatException e1) {
            if (!listEtat.contains(tField3.getText().replaceAll(" ", ""))) {//on a utilisé un état non déclaré
                result += "Attention! l'état '" + tField3.getText().replaceAll(" ", "") + "' dans une instruction n'a pas été défini.\n";
            }
        }
        return result;
    }

}
